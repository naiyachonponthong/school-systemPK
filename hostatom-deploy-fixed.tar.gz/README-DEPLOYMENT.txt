# HostAtom Deployment Instructions

## ไฟล์ที่อัปโหลด:
- แตกไฟล์ ZIP นี้ใน HostAtom File Manager
- วางไว้ในโฟลเดอร์หลัก (public_html หรือที่กำหนด)

## ขั้นตอนหลังอัปโหลด:

### 1. ติดตั้ง Dependencies:
```bash
npm install --production
```

### 2. สร้างตารางฐานข้อมูล:
```bash
node -e "
const sequelize = require('./config/database');
require('./models');
sequelize.sync({ force: true }).then(() => {
  console.log('Database synced!');
  process.exit(0);
});
"
```

### 3. รัน Application:
```bash
npm start
```

### 4. ข้อมูลเข้าใช้งาน:
- Username: admin
- Password: admin123
- URL: http://your-domain.com:10000

## หมายเหตุ:
- Environment variables ถูกตั้งค่าไว้แล้วในไฟล์ .env
- Port 10000 ตามที่ HostAtom กำหนด
- Database พร้อมใช้งานแล้ว
